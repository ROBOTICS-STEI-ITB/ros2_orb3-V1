import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped
from std_msgs.msg import String
from std_msgs.msg import Float64
import asyncio
import websockets
import json
import threading
import time

WS_URI = "ws://10.192.238.52:8765"


class PoseSender(Node):
    def __init__(self):
        super().__init__('pose_ws_sender')

        # ROS subscribers
        self.subscription = self.create_subscription(
            PoseStamped,
            '/orbslam3/pose',
            self.pose_callback,
            10
        )

        self.status_sub = self.create_subscription(
            String,
            '/orbslam3/tracking_status',
            self.status_callback,
            10
        )

        self.compute_sub = self.create_subscription(
            Float64,
            '/orbslam3/compute_time_ms',
            self.compute_time_callback,
            10
        )
        
        self.loop_sub = self.create_subscription(
            String,
            '/orbslam3/loop_status',
            self.loop_callback,
            10
        )
        
        self.compute_time_ms = 0.0

        # WebSocket state
        self.websocket = None
        self.connecting = False

        # Pose cache
        self.latest_pose = None
        self.last_pose_time = 0.0
        self.last_sent_time = 0.0
        self.send_interval = 0.5  # seconds

        # Tracking state
        self.tracking_status = "INITIALIZE"
        self.loop_status = "NO_LOOP"

        # Timers
        self.create_timer(0.5, self.check_tracking)     # update tracking state
        self.create_timer(0.5, self.publish_heartbeat)  # always send status

        # Async event loop in separate thread
        self.loop = asyncio.new_event_loop()
        self.ws_thread = threading.Thread(target=self.start_loop, daemon=True)
        self.ws_thread.start()

        asyncio.run_coroutine_threadsafe(self.connect(), self.loop)

    # =========================
    # Async / WebSocket section
    # =========================
    def start_loop(self):
        asyncio.set_event_loop(self.loop)
        self.loop.run_forever()

    async def connect(self):
        if self.connecting:
            return

        self.connecting = True

        while True:
            try:
                self.websocket = await websockets.connect(
                    WS_URI,
                    ping_interval=20,
                    ping_timeout=20
                )
                await self.websocket.send("producer")
                self.get_logger().info("Connected to WebSocket server")
                self.connecting = False
                return

            except Exception as e:
                self.websocket = None
                self.get_logger().warn(f"Retrying connection... {e}")
                await asyncio.sleep(1)

    async def safe_send(self, data):
        try:
            if self.websocket is None or self.websocket.state.name != "OPEN":
                return

            await self.websocket.send(json.dumps(data))

        except Exception as e:
            self.get_logger().warn(f"Send failed: {e}")
            self.websocket = None
            asyncio.create_task(self.connect())

    def send_json(self, data):
        asyncio.run_coroutine_threadsafe(
            self.safe_send(data),
            self.loop
        )

    # =========================
    # ROS callbacks
    # =========================
    def status_callback(self, msg):
        self.tracking_status = msg.data

    def pose_callback(self, msg):
        now = time.time()

        # cache pose terbaru
        self.last_pose_time = now
        self.latest_pose = msg

        # throttle pose sending
        if now - self.last_sent_time < self.send_interval:
            return

        self.last_sent_time = now
        self.send_pose(msg)
    
    def compute_time_callback(self, msg):
        self.compute_time_ms = msg.data
        
    def loop_callback(self, msg):
        self.loop_status = msg.data
    # =========================
    # Data handling
    # =========================
    def send_pose(self, msg):
        stamp = msg.header.stamp.sec + msg.header.stamp.nanosec * 1e-9

        data = {
            "type": "pose",
            "x": msg.pose.position.x,
            "y": msg.pose.position.y,
            "z": msg.pose.position.z,
            "qx": msg.pose.orientation.x,
            "qy": msg.pose.orientation.y,
            "qz": msg.pose.orientation.z,
            "qw": msg.pose.orientation.w,
            "timestamp": stamp,
            "tracking_status": self.tracking_status,
            "loop_status": self.loop_status,
            "compute_time_ms": self.compute_time_ms
        }

        self.send_json(data)

    def publish_heartbeat(self):
        now = time.time()

        # Tentukan status stream
        if now - self.last_pose_time > 1.0:
            stream_status = "NO_DATA"
        else:
            stream_status = "LIVE"

        data = {
            "type": "heartbeat",
            "timestamp": now,
            "tracking_status": self.tracking_status,
            "stream_status": stream_status,
            "loop_status": self.loop_status,
            "compute_time_ms": self.compute_time_ms
        }

        self.send_json(data)

    def check_tracking(self):
        # Jika pose lama tidak masuk, tandai lost
        if time.time() - self.last_pose_time > 1.0:
            self.tracking_status = "LOST"


def main():
    rclpy.init()
    node = PoseSender()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass

    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
