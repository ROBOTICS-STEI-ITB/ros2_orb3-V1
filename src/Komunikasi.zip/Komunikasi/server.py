import asyncio
import websockets

browser_clients = set()
producer = None


async def handler(websocket):
    global producer

    try:
        role = await websocket.recv()

        if role == "producer":
            producer = websocket
            print("Producer connected")

            try:
                async for message in websocket:
                    dead_clients = set()

                    for client in browser_clients:
                        try:
                            await client.send(message)
                        except Exception as e:
                            print(f"Browser send error: {e}")
                            dead_clients.add(client)

                    browser_clients.difference_update(dead_clients)

            except Exception as e:
                print(f"Producer error: {e}")

            finally:
                if producer == websocket:
                    producer = None
                print("Producer disconnected")

        elif role == "browser":
            browser_clients.add(websocket)
            print("Browser connected")

            try:
                await websocket.wait_closed()
            finally:
                browser_clients.discard(websocket)
                print("Browser disconnected")

        else:
            print(f"Unknown client role: {role}")
            await websocket.close()

    except Exception as e:
        print(f"Handler error: {e}")


async def main():
    async with websockets.serve(handler, "0.0.0.0", 8765):
        print("WebSocket server running on port 8765")
        await asyncio.Future()   # keep server alive forever


if __name__ == "__main__":
    asyncio.run(main())
